﻿namespace Coffeeshop
{
    partial class Formmain
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.sellpage = new System.Windows.Forms.TabPage();
            this.addpage = new System.Windows.Forms.TabPage();
            this.coffeepage = new System.Windows.Forms.TabPage();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.sellpage);
            this.tabControl1.Controls.Add(this.addpage);
            this.tabControl1.Controls.Add(this.coffeepage);
            this.tabControl1.Location = new System.Drawing.Point(2, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(561, 330);
            this.tabControl1.TabIndex = 0;
            // 
            // sellpage
            // 
            this.sellpage.Location = new System.Drawing.Point(4, 22);
            this.sellpage.Name = "sellpage";
            this.sellpage.Padding = new System.Windows.Forms.Padding(3);
            this.sellpage.Size = new System.Drawing.Size(553, 304);
            this.sellpage.TabIndex = 0;
            this.sellpage.Text = "Продажа";
            this.sellpage.UseVisualStyleBackColor = true;
            // 
            // addpage
            // 
            this.addpage.Location = new System.Drawing.Point(4, 22);
            this.addpage.Name = "addpage";
            this.addpage.Padding = new System.Windows.Forms.Padding(3);
            this.addpage.Size = new System.Drawing.Size(553, 304);
            this.addpage.TabIndex = 1;
            this.addpage.Text = "Поступление";
            this.addpage.UseVisualStyleBackColor = true;
            // 
            // coffeepage
            // 
            this.coffeepage.Location = new System.Drawing.Point(4, 22);
            this.coffeepage.Name = "coffeepage";
            this.coffeepage.Padding = new System.Windows.Forms.Padding(3);
            this.coffeepage.Size = new System.Drawing.Size(553, 304);
            this.coffeepage.TabIndex = 2;
            this.coffeepage.Text = "Приготовление кофе";
            this.coffeepage.UseVisualStyleBackColor = true;
            // 
            // Formmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(561, 332);
            this.Controls.Add(this.tabControl1);
            this.Name = "Formmain";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage sellpage;
        private System.Windows.Forms.TabPage addpage;
        private System.Windows.Forms.TabPage coffeepage;
    }
}

